CREATE TRIGGER acc_tri
AFTER DELETE ON t_account
FOR EACH ROW
  begin
	# 关于值的获取
	# 如果表中有记录,则用old.列名
	# 如果表中没有记录,则用new.列名
	insert into trigger_tbl values(old.id,old.accno,old.balance);
end;
