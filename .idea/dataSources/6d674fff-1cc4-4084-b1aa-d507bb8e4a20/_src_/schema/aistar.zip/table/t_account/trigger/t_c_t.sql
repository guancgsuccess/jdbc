CREATE TRIGGER t_c_t
AFTER DELETE ON t_account
FOR EACH ROW
  begin
insert into t_c values(old.id,old.accno,old.balance);
end;
