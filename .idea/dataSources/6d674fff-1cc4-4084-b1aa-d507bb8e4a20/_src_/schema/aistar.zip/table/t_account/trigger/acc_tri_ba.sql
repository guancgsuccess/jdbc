CREATE TRIGGER acc_tri_ba
BEFORE INSERT ON t_account
FOR EACH ROW
  begin
	declare msg varchar(20);
	if new.balance < 0 then
		set msg = "余额不能为负数";
		# 触发器中不需要返回结果
		# select msg;
		# 如果给定的列不满足,则给定一个默认值的处理方式
		set new.balance = 10.0;
		# 抛出一个异常.
		SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = msg;
	else
		set msg = "插入成功";
		# select msg;
	end if;
end;
