CREATE PROCEDURE transfer_acc_pro(IN status INT(7), IN srcano VARCHAR(20), IN targetano VARCHAR(20),
                                  IN money  DOUBLE(7, 2), OUT res VARCHAR(20))
  begin

START TRANSACTION;


UPDATE t_account SET balance = balance - money WHERE accno = srcano;

if status = 1 then
set res = "更新失败!";
select res;
ROLLBACK;
else
UPDATE t_account SET balance = balance + money WHERE accno = targetano;
set res = "转账成功!";
select res;
end if;
COMMIT;
end;
