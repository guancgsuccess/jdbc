CREATE PROCEDURE while_pro()
  begin

declare vars int;
set vars  = 0;
while vars<6 do
        select vars;
set vars = vars+1;
end while;
end;
