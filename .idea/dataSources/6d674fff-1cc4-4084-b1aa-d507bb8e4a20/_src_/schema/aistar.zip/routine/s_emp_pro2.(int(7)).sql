CREATE PROCEDURE s_emp_pro2(IN ids INT(7), OUT fname VARCHAR(25), OUT sal FLOAT(11, 2))
  begin
select first_name,salary into fname,sal from s_emp where id = ids;
end;
