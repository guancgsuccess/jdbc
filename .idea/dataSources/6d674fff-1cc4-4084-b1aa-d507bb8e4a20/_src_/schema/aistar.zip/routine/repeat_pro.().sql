CREATE PROCEDURE repeat_pro()
  begin
declare v int;
set v=0;
repeat
set v = v + 1;
select v;
until v>0
    end repeat;
 end;
