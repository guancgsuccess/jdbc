CREATE PROCEDURE ins_pro(OUT p_in INT)
  begin
	-- 打印
	select p_in;
	-- 对局部变量进行重新设置值
	set p_in = 2;
	select p_in;
	
	-- 局部变量在使用之前,一定要先声明.
	-- set p = 100;
	set @p_in2 = 100; -- 全局变量,无需先声明
end;
