CREATE PROCEDURE loop_pro()
  begin
declare v int;
set v = 0;
loop_lable01:LOOP
select v;
set v = v +1;
if v>=2 then
LEAVE loop_lable01;
end if;
end LOOP;
end;
