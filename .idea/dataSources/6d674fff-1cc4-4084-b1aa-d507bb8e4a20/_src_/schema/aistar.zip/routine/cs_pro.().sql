CREATE PROCEDURE cs_pro()
  begin
declare v varchar(100);
declare v_i int(10) default 1;
DECLARE done INT DEFAULT 0;

declare cs cursor for select ordno from t_ord;


select count(*) from t_ord into done;
select done;
select v_i;

open cs;
  while done>=v_i do
  
fetch cs into v;
select v;
set v_i = v_i + 1;
end while;

close cs;
end;
