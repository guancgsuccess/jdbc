CREATE PROCEDURE if_pro(IN param INT)
  begin
if param=0 then
select 1;
end if;
if param=2 then
select 2;
else
select 3;
end if;
end;
