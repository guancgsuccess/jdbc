CREATE PROCEDURE s_emp_pro(IN ids INT(7), OUT fname VARCHAR(25), IN sal FLOAT(11, 2))
  begin
select first_name into fname from s_emp where id = ids;
select salary into sal from s_emp where id = ids;
end;
