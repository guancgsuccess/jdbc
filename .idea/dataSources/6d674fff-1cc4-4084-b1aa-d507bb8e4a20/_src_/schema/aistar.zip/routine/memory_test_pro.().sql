CREATE PROCEDURE memory_test_pro()
  begin
declare i int(7);
set i = 0;
while i<1000000 do
insert into memory_test(uid,cid,tid) values(round(rand()*10000+1),round(rand()*10000+1),round(rand()*10000+1));
        set i = i + 1;
    end while;   
end;
