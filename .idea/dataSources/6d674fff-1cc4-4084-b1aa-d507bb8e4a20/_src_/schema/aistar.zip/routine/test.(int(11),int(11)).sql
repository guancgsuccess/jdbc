CREATE FUNCTION test(m INT, n INT)
  RETURNS INT
  begin
	return m + n;
end;
