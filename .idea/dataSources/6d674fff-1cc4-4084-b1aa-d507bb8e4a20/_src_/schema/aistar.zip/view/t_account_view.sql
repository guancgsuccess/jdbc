CREATE VIEW t_account_view AS
  SELECT
    `aistar`.`t_account`.`id`      AS `id`,
    `aistar`.`t_account`.`balance` AS `balance`
  FROM `aistar`.`t_account`;
