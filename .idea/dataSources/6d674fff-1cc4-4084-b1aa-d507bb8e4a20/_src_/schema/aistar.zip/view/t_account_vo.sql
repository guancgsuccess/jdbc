CREATE VIEW t_account_vo AS
  SELECT
    `aistar`.`t_account`.`id`      AS `id`,
    `aistar`.`t_account`.`accno`   AS `accno`,
    `aistar`.`t_account`.`balance` AS `balance`
  FROM `aistar`.`t_account`
  WHERE (`aistar`.`t_account`.`id` = 2);
