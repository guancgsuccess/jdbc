CREATE VIEW t_customer_v AS
  SELECT
    `c`.`id`    AS `cids`,
    `c`.`cname` AS `cname`,
    `o`.`id`    AS `id`,
    `o`.`ordno` AS `ordno`,
    `o`.`cid`   AS `cid`
  FROM (`aistar`.`t_customer` `c` LEFT JOIN `aistar`.`t_ord` `o` ON ((`c`.`id` = `o`.`cid`)));
